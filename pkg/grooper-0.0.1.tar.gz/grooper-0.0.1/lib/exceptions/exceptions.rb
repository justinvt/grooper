module Grooper
  
  module Exceptions
  
  end
  
end